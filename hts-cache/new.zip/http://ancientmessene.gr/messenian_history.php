<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Ithome, Messene, Asclepieion, Asclepius, Stadion, Heroon, Mausoleum, Klepsydra, Arsinoe, Themelis, Ιθώμη, Μεσσήνη, Ασκληπιείο, Ασκληπιός, Στάδιο, Ηρώο, Μαυσωλείο, Κλεψύδρα, Αρσινόη, Θέμελης">
<meta name="description" content="Ancient Messene counts among the most important excavated cities in Greece. It comprises monumental public buildings, sanctuaries, grave monuments and mighty fortifications. Η Αρχαία Μεσσήνη περιλαμβάνεται ανάμεσα στις σημαντικότερες ανασκαμμένες πόλεις της Ελλάδας και περιλαμβάνει μνημειώδη δημόσια οικοδομήματα, ιερά, ταφικά μνημεία και πανίσχυρες οχυρώσεις. ">
<META name="robots" content="all">
<META name="robots" content="index,follow">
<title>Ithome, Messene, Asclepieion, Asclepius, Stadion, Heroon, Mausoleum, Klepsydra, Arsinoe, Themelis, Ιθώμη, Μεσσήνη, Ασκληπιείο, Ασκληπιός, Στάδιο, Ηρώο, Μαυσωλείο, Κλεψύδρα, Αρσινόη, Θέμελης</title><link href="styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-1.4.3.min.js"></script>

</head>
<body>
<table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" class="td_menu"><table width="332" border="0" cellspacing="0" cellpadding="0">
           <tr>
        <td colspan="4"><table width="332" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="4"><img src="images/ancientmessene_01.png" alt="αρχαια μεσσηνη" width="332" height="122" border="0" usemap="#Map" />
      <map name="Map" id="Map">
        <area shape="rect" coords="57,38,320,104" href="index.php" />
      </map></td>
  </tr>
  <tr>
    <td><img src="images/ancientmessene_03.png" width="59" height="36" alt="αρχαια μεσσηνη"/></td>
    <td><a href="/messenian_history.php"><img src="images/ancientmessene_04.png" width="35" height="36" alt="αρχαια μεσσηνη" border="0"/></a></td>
    <td><a href="/messenian_history_en.php"><img src="images/ancientmessene_05.png" width="37" height="36" alt="αρχαια μεσσηνη" border="0"/></a></td>
    <td><img src="images/ancientmessene_06.png" width="201" height="36" alt="αρχαια μεσσηνη"/></td>
  </tr>
</table>

</td>
      </tr>
      <tr>
        <td colspan="4" class="td_menu">
<script type="text/javascript">
<!--//---------------------------------+
//  Developed by Roshan Bhattarai 
//  Visit http://roshanbh.com.np for this script and more.
//  This notice MUST stay intact for legal use
// --------------------------------->
$(document).ready(function()
{
	$("#firstpane p.menu_head").click(function()
    {
		$(this).css({backgroundImage:"url(down.png)"}).next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
       	$(this).siblings().css({backgroundImage:"url(left.png)"});
	});

});
 

</script>
<style type="text/css">

.menu_list {	
	width: 260px;
	
}
.menu_head {
	cursor: pointer;
	position: relative;
	margin:0px;


}

.menu_head1 {
	cursor: pointer;
	position: relative;
	margin:0px;
    font-weight:bold;
	background-image: url(images/bg_menu_buttons_.png);
	background-repeat:no-repeat;
}
.menu_body {
	display:none;
	width: 260px; padding-left:60px; padding-bottom:20px
	
}
.menu_body a{
  display:block;
color:#ffffff;
font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:12px;
font-weight:bold;
-webkit-transition-property:color, text;
-webkit-transition-duration: 0.2s, 0.2s;
-webkit-transition-timing-function: linear, ease-in;

-moz-transition-property:color, text;
-moz-transition-duration:0.2s;
-moz-transition-timing-function: linear, ease-in;

-o-transition-property:color, text;
-o-transition-duration:0.2s;
-o-transition-timing-function: linear, ease-in;
}
.menu_body a:hover{
color: #CCCCCC;
  }
  
</style>
  <script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body><div>
<div id="firstpane" class="menu_list"> <!--Code for menu starts here-->
<p class="menu_head1">            <a href="messenian_history.php"><img src="images/menu/menu1on.png" name="ImageM1" width="332" height="50" border="0" alt="αρχαια μεσσηνη"></a>
          </p>
          
          <p class="menu_head">          <a href="history.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM21','','images/menu/menu2on.png',1)"><img src="images/menu/menu2.png" name="ImageM21" width="332" height="40" border="0" id="ImageM21" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="the-site.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM31','','images/menu/menu3on.png',1)"><img src="images/menu/menu3.png" name="ImageM31" width="332" height="38" border="0" id="ImageM31" alt="αρχαια μεσσηνη" /></a>
          </p>
          
  <p class="menu_head"><img src="images/menu/menu4.png" alt="αρχαια μεσσηνη" name="Image00" width="332" height="40" border="0" onMouseOver="MM_swapImage('Image00','','images/menu/menu4on.png',1)" onMouseOut="MM_swapImgRestore()"/></p>
  <div class="menu_body"><a href='monuments_articles.php?id=12''><img src='images/menu_arrow.png' border=0>&nbsp;Το Θέατρο - Η Κρήνη Αρσινόη</a><a href='monuments_articles.php?id=18''><img src='images/menu_arrow.png' border=0>&nbsp;Η Αγορά - Το Ιερό Δήμητρας &amp; Διόσκουρων</a><a href='monuments_articles.php?id=13''><img src='images/menu_arrow.png' border=0>&nbsp;Το συγκρότημα του Ασκληπιείου</a><a href='monuments_articles.php?id=19''><img src='images/menu_arrow.png' border=0>&nbsp;Η Ανατολική οδός - Το Ιεροθύσιο</a><a href='monuments_articles.php?id=15''><img src='images/menu_arrow.png' border=0>&nbsp;Το Στάδιο και το Γυμνάσιο - Το Ηρώο</a><a href='monuments_articles.php?id=14''><img src='images/menu_arrow.png' border=0>&nbsp;Τα Ιερά της Ιθώμης</a><a href='monuments_articles.php?id=22''><img src='images/menu_arrow.png' border=0>&nbsp;Συντήρηση</a></div>
          
  <p class="menu_head"><img src="images/menu/menu5.png" alt="αρχαια μεσσηνη" width="332" height="39" border="0" id="Image1" onMouseOver="MM_swapImage('Image1','','images/menu/menu5on.png',1)" onMouseOut="MM_swapImgRestore()" /></p>
  <div class="menu_body"><a href='findings_articles.php?id=11''><img src='images/menu_arrow.png' border=0>&nbsp;Η γλυπτική της Μεσσήνης</a><a href='findings_articles.php?id=9''><img src='images/menu_arrow.png' border=0>&nbsp;Η συμβολή των επιγραφών στη γνώση της μεσσηνιακής ιστορίας</a><a href='findings_articles.php?id=10''><img src='images/menu_arrow.png' border=0>&nbsp;Η νομισματοκοπία της Μεσσήνης</a><a href='findings_articles.php?id=8''><img src='images/menu_arrow.png' border=0>&nbsp;Η κεραμική της Μεσσήνης</a><a href='findings_articles.php?id=12''><img src='images/menu_arrow.png' border=0>&nbsp;Συντήρηση</a></div>
          
  <p class="menu_head"><img src="images/menu/menu6.png" alt="αρχαια μεσσηνη" width="332" height="40" border="0" id="Image2" onMouseOver="MM_swapImage('Image2','','images/menu/menu6on.png',1)" onMouseOut="MM_swapImgRestore()"/></p>
  <div class="menu_body"><a href='museum_articles.php?id=10''><img src='images/menu_arrow.png' border=0>&nbsp;Πληροφορίες</a><a href='museum_articles.php?id=7''><img src='images/menu_arrow.png' border=0>&nbsp;Αίθουσα Α</a><a href='museum_articles.php?id=8''><img src='images/menu_arrow.png' border=0>&nbsp;Αίθουσα Β</a><a href='museum_articles.php?id=9''><img src='images/menu_arrow.png' border=0>&nbsp;Αίθουσα Γ</a></div>
          
          <p class="menu_head">          <a href="bibliography.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM71','','images/menu/menu7on.png',1)"><img src="images/menu/menu7.png" name="ImageM71" width="332" height="40" border="0" id="ImageM71" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="publications.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM81','','images/menu/menu8on.png',1)"><img src="images/menu/menu8.png" name="ImageM81" width="332" height="41" border="0" id="ImageM81" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="news.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM91','','images/menu/menu9on.png',1)"><img src="images/menu/menu9.png" name="ImageM91" width="332" height="40" border="0" id="ImageM91" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="video.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM92','','images/menu/video_on.png',1)"><img src="images/menu/video.png" name="ImageM92" width="332" height="40" border="0" id="ImageM92" alt="αρχαια μεσσηνη" /></a>
          </p>
          
  <p class="menu_head">          <a href="management.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM101','','images/menu/menu10on.png',1)"><img src="images/menu/menu10.png" name="ImageM101" width="332" height="40" border="0" id="ImageM101" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="contests.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM111','','images/menu/menu11on.png',1)"><img src="images/menu/menu11.png" name="ImageM111" width="332" height="40" border="0" id="ImageM111" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="newsletter.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM121','','images/menu/menu12on.png',1)"><img src="images/menu/menu12.png" name="ImageM121" width="332" height="40" border="0" id="ImageM121" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="contact.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM131','','images/menu/menu13on.png',1)"><img src="images/menu/menu13.png" name="ImageM131" width="332" height="44" border="0" id="ImageM131" alt="αρχαια μεσσηνη" /></a>
  </p>
         
        
</div></td>
      </tr>
      <tr>
        <td colspan="4" class="td_menu"><style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
<table width="324" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><a href="monuments_gallery.php"><img src="images/monuments_gallery.png" alt="αρχαια μεσσηνη" width="332" height="117" border="0" /></a></td>
  </tr>
  <tr>
    <td><a href="museum_gallery.php"><img src="images/museum_gallery.png" alt="αρχαια μεσσηνη" width="332" height="113" border="0" /></a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="padding-left:80px"><table border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2" class="style1 txt"><div align="center"><strong>Εφαρμογή ψηφιακής ξενάγησης<br />
          (μέσω κινητού)</strong></div></td>
        </tr>
      <tr>
        <td colspan="2" style="padding-top:10px"><div align="center"><img src="images/messene_app.png" alt="ancient messene" width="154" height="47" /></div></td>
        </tr>
      <tr>
        <td style="padding-top:10px"><div align="center"><a href="http://itunes.apple.com/us/app/messene/id498466711?mt=8" target="_blank"><img src="images/app_store.png" alt="ancient messene" width="90" height="30" border="0" /></a></div></td>
        <td style="padding-top:10px"><div align="center"><a href="https://play.google.com/store/apps/details?id=gr.apt.messene.gr" target="_blank"><img src="images/android_market.png" alt="ancient messene" width="90" height="30" border="0" /></a></div></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</td>
      </tr>
      
    </table></td>
    <td width="628" valign="top" background="images/bg_content.png"><table width="628" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="628" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="309" background="images/ancientmessene_02.png"><script type="text/javascript">

/*** 
    Simple jQuery Slideshow Script
    Released by Jon Raasch (jonraasch.com) under FreeBSD license: free to use or modify, not responsible for anything, etc.  Please link out to me if you like it :)
***/

function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');

    // uncomment the 3 lines below to pull the images in random order
    
    // var $sibs  = $active.siblings();
    // var rndNum = Math.floor(Math.random() * $sibs.length );
    // var $next  = $( $sibs[ rndNum ] );


    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 5000 );
});

</script>

<style type="text/css">

/*** set the width and height to match your images **/

#slideshow {
    position:relative;
    height:309px;
	width:628px;
}

#slideshow IMG {
    position:absolute;
    top:0;
    left:0;
    z-index:8;
    opacity:0.0;
}

#slideshow IMG.active {
    z-index:10;
    opacity:1.0;
}

#slideshow IMG.last-active {
    z-index:9;
}
</style>
<div id="slideshow">
    <img src="content/slideshow/1.png" alt="Αρχαία Μεσσήνη" class="active" border="0" />
    <img src="content/slideshow/2.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/3.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/4.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/5.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/6.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/7.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/8.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/9.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/10.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/11.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/12.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/13.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/14.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/15.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/16.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/17.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/18.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/19.png" alt="Αρχαία Μεσσήνη" border="0" />
</div></td>
  </tr>
  <tr>
    <td><img src="images/ancientmessene_11.png" width="628" height="56" alt="αρχαια μεσσηνη" /></td>
  </tr>
</table>
</td>
      </tr>
      <tr>
        <td valign="top" class="content"><table width="555" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td class="txt"><p>
	<strong><a href="/site/content/files/images/found.jpg" target="_blank"><img alt="" src="/site/content/files/images/found.jpg" style="border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; margin-left: 10px; margin-right: 10px; margin-top: 10px; margin-bottom: 10px; float: left; width: 150px; height: 243px; " /></a>H ΙΔΡΥΣΗ ΤΗΣ ΜΕΣΣΗΝΗΣ ΚΑΙ ΤΟ ΠΟΛΕΟΔΟΜΙΚΟ ΤΗΣ ΣΥΣΤΗΜΑ</strong></p>
<p style="text-align: justify;">
	Όλα τα οικοδομήματα της Μεσσήνης έχουν τον ίδιο προσανατολισμό και εντάσσονται μέσα στον κάνναβο που δημιουργείται από οριζόντιους (με κατεύθυνση Ανατολή-Δύση) και κάθετους (με κατεύθυνση Βορρά-Νότου) δρόμους. Το πολεοδομικό αυτό σύστημα είναι γνωστό ως ιπποδάμειο, από τον αρχικό εμπνευστή και δημιουργό του αρχιτέκτονα, πολεοδόμο, γεωμέτρη και αστρονόμο του 5ου αιώνα π.Χ., τον Ιππόδαμο από τη Μίλητο. Αξιοσημείωτο είναι ότι το προκαθορισμένο αυτό σχήμα που στηρίζεται στις αρχές της ισονομίας, της ισοπολιτείας και της ισομοιρίας, στις αρετές δηλαδή του δημοκρατικού πολιτεύματος, και χαρακτηρίζεται από ακραίο γεωμετρισμό, προσαρμοζόταν κάθε φορά στις ειδικές γεωμορφολογικές και κλιματολογικές συνθήκες του τόπου, ενταγμένο αρμονικά στο φυσικό περιβάλλον. Η βασική ιδέα του ιπποδάμειου πολεοδομικού συστήματος που πηγάζει από το ιδεώδες της δημοκρατίας είναι: όλοι οι πολίτες να έχουν ισομεγέθη και εξίσου κατάλληλα οικόπεδα και να έχουν πρόσβαση στα δημόσια και ιερά οικοδομήματα, στους κοινόχρηστους δηλαδή χώρους, που επιβάλλονται με τις μνημειακές τους διαστάσεις και τον πλούσιο διάκοσμο. Πάνω σε αυτές ακριβώς τις αρχές οικοδομήθηκε το 369 π.Χ. από τον Θηβαίο Επαμεινώνδα και τους Αργείους συμμάχους του η νέα πρωτεύουσα της αυτόνομης Μεσσηνίας, που οφείλει το όνομα της στην πρώτη μυθική προδωρική βασίλισσα της χώρας, τη Μεσσήνη, κόρη του Αργείου βασιλιά Τριόπα και σύζυγο του Λάκωνα Πολυκάονα.</p>
<p style="text-align: justify;">
	Στη βασίλισσα Μεσσήνη αποδίδεται κατά την παράδοση και η ίδρυση του ιερού του Διός Ιθωμάτα στην κορυφή της Ιθώμης (Παυσανίας 4.26-33). Ο Παυσανίας μας πληροφορεί επίσης ότι ήδη επί της βασιλείας του Γλαύκου (10ος αι. π.Χ.) η Μεσσήνη θεοποιείται και λατρεύεται. Αναδείχθηκε σε μια από τις κύριες θεότητες της πόλης μαζί με τον Δία Ιθωμάτα. Ο ναός της αποκαλύφθηκε στο ΝΔ τμήμα της αγοράς. Είναι περίπτερος με 6 Χ 12 ψαμμιτικούς κίονες δωρικού ρυθμού. Στο σηκό του βρισκόταν το χρυσόλιθο άγαλμα της θεάς και μια τοιχογραφία του Ομφαλίωνα, μαθητή του Νικία, με δεκατρείς μυθικούς βασιλείς και βασίλισσες της χώρας.</p></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  <tr>
    <td colspan="2"><table width="960" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="footer">Copyright © 2013 Εταιρεία Μεσσηνιακών Αρχαιολογικών Σπουδών - All rights reserved.</td>
  </tr>
</table>
<div style="text-indent:-9999px; position:fixed">
<a href="http://www.elektroniksigaraevi.us/elektronik-sigara/" title="Elektronik sigara">elektronik sigara</a>
</div></td>
  </tr>
</table>
</body>
</html>
