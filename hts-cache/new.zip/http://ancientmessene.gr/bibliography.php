<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Ithome, Messene, Asclepieion, Asclepius, Stadion, Heroon, Mausoleum, Klepsydra, Arsinoe, Themelis, Ιθώμη, Μεσσήνη, Ασκληπιείο, Ασκληπιός, Στάδιο, Ηρώο, Μαυσωλείο, Κλεψύδρα, Αρσινόη, Θέμελης">
<meta name="description" content="Ancient Messene counts among the most important excavated cities in Greece. It comprises monumental public buildings, sanctuaries, grave monuments and mighty fortifications. Η Αρχαία Μεσσήνη περιλαμβάνεται ανάμεσα στις σημαντικότερες ανασκαμμένες πόλεις της Ελλάδας και περιλαμβάνει μνημειώδη δημόσια οικοδομήματα, ιερά, ταφικά μνημεία και πανίσχυρες οχυρώσεις. ">
<META name="robots" content="all">
<META name="robots" content="index,follow">
<title>Ithome, Messene, Asclepieion, Asclepius, Stadion, Heroon, Mausoleum, Klepsydra, Arsinoe, Themelis, Ιθώμη, Μεσσήνη, Ασκληπιείο, Ασκληπιός, Στάδιο, Ηρώο, Μαυσωλείο, Κλεψύδρα, Αρσινόη, Θέμελης</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-1.4.3.min.js"></script>

</head>
<style>
a:link {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px;	color: #000000;}
a:visited {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px;	color: #000000;}
a:hover {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px; color: #9A8A66;}
a:active {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px;	color: #000000;}
</style>
<body>
<table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" class="td_menu"><table width="332" border="0" cellspacing="0" cellpadding="0">
                 <tr>
        <td colspan="4"><table width="332" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="4"><img src="images/ancientmessene_01.png" alt="αρχαια μεσσηνη" width="332" height="122" border="0" usemap="#Map" />
      <map name="Map" id="Map">
        <area shape="rect" coords="57,38,320,104" href="index.php" />
      </map></td>
  </tr>
  <tr>
    <td><img src="images/ancientmessene_03.png" width="59" height="36" alt="αρχαια μεσσηνη"/></td>
    <td><a href="/bibliography.php"><img src="images/ancientmessene_04.png" width="35" height="36" alt="αρχαια μεσσηνη" border="0"/></a></td>
    <td><a href="/bibliography_en.php"><img src="images/ancientmessene_05.png" width="37" height="36" alt="αρχαια μεσσηνη" border="0"/></a></td>
    <td><img src="images/ancientmessene_06.png" width="201" height="36" alt="αρχαια μεσσηνη"/></td>
  </tr>
</table>

</td>
      </tr>
      <tr>
        <td colspan="4" class="td_menu">
<script type="text/javascript">
<!--//---------------------------------+
//  Developed by Roshan Bhattarai 
//  Visit http://roshanbh.com.np for this script and more.
//  This notice MUST stay intact for legal use
// --------------------------------->
$(document).ready(function()
{
	$("#firstpane p.menu_head").click(function()
    {
		$(this).css({backgroundImage:"url(down.png)"}).next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
       	$(this).siblings().css({backgroundImage:"url(left.png)"});
	});

});
 

</script>
<style type="text/css">

.menu_list {	
	width: 260px;
	
}
.menu_head {
	cursor: pointer;
	position: relative;
	margin:0px;


}

.menu_head1 {
	cursor: pointer;
	position: relative;
	margin:0px;
    font-weight:bold;
	background-image: url(images/bg_menu_buttons_.png);
	background-repeat:no-repeat;
}
.menu_body {
	display:none;
	width: 260px; padding-left:60px; padding-bottom:20px
	
}
.menu_body a{
  display:block;
color:#ffffff;
font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:12px;
font-weight:bold;
-webkit-transition-property:color, text;
-webkit-transition-duration: 0.2s, 0.2s;
-webkit-transition-timing-function: linear, ease-in;

-moz-transition-property:color, text;
-moz-transition-duration:0.2s;
-moz-transition-timing-function: linear, ease-in;

-o-transition-property:color, text;
-o-transition-duration:0.2s;
-o-transition-timing-function: linear, ease-in;
}
.menu_body a:hover{
color: #CCCCCC;
  }
  
</style>
  <script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body><div>
<div id="firstpane" class="menu_list"> <!--Code for menu starts here-->
<p class="menu_head1">          <a href="messenian_history.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM14','','images/menu/menu1on.png',1)"><img src="images/menu/menu1.png" name="ImageM14" width="332" height="50" border="0" id="ImageM14" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="history.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM21','','images/menu/menu2on.png',1)"><img src="images/menu/menu2.png" name="ImageM21" width="332" height="40" border="0" id="ImageM21" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="the-site.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM31','','images/menu/menu3on.png',1)"><img src="images/menu/menu3.png" name="ImageM31" width="332" height="38" border="0" id="ImageM31" alt="αρχαια μεσσηνη" /></a>
          </p>
          
  <p class="menu_head"><img src="images/menu/menu4.png" alt="αρχαια μεσσηνη" name="Image00" width="332" height="40" border="0" onMouseOver="MM_swapImage('Image00','','images/menu/menu4on.png',1)" onMouseOut="MM_swapImgRestore()"/></p>
  <div class="menu_body"><a href='monuments_articles.php?id=12''><img src='images/menu_arrow.png' border=0>&nbsp;Το Θέατρο - Η Κρήνη Αρσινόη</a><a href='monuments_articles.php?id=18''><img src='images/menu_arrow.png' border=0>&nbsp;Η Αγορά - Το Ιερό Δήμητρας &amp; Διόσκουρων</a><a href='monuments_articles.php?id=13''><img src='images/menu_arrow.png' border=0>&nbsp;Το συγκρότημα του Ασκληπιείου</a><a href='monuments_articles.php?id=19''><img src='images/menu_arrow.png' border=0>&nbsp;Η Ανατολική οδός - Το Ιεροθύσιο</a><a href='monuments_articles.php?id=15''><img src='images/menu_arrow.png' border=0>&nbsp;Το Στάδιο και το Γυμνάσιο - Το Ηρώο</a><a href='monuments_articles.php?id=14''><img src='images/menu_arrow.png' border=0>&nbsp;Τα Ιερά της Ιθώμης</a><a href='monuments_articles.php?id=22''><img src='images/menu_arrow.png' border=0>&nbsp;Συντήρηση</a></div>
          
  <p class="menu_head"><img src="images/menu/menu5.png" alt="αρχαια μεσσηνη" width="332" height="39" border="0" id="Image1" onMouseOver="MM_swapImage('Image1','','images/menu/menu5on.png',1)" onMouseOut="MM_swapImgRestore()" /></p>
  <div class="menu_body"><a href='findings_articles.php?id=11''><img src='images/menu_arrow.png' border=0>&nbsp;Η γλυπτική της Μεσσήνης</a><a href='findings_articles.php?id=9''><img src='images/menu_arrow.png' border=0>&nbsp;Η συμβολή των επιγραφών στη γνώση της μεσσηνιακής ιστορίας</a><a href='findings_articles.php?id=10''><img src='images/menu_arrow.png' border=0>&nbsp;Η νομισματοκοπία της Μεσσήνης</a><a href='findings_articles.php?id=8''><img src='images/menu_arrow.png' border=0>&nbsp;Η κεραμική της Μεσσήνης</a><a href='findings_articles.php?id=12''><img src='images/menu_arrow.png' border=0>&nbsp;Συντήρηση</a></div>
          
  <p class="menu_head"><img src="images/menu/menu6.png" alt="αρχαια μεσσηνη" width="332" height="40" border="0" id="Image2" onMouseOver="MM_swapImage('Image2','','images/menu/menu6on.png',1)" onMouseOut="MM_swapImgRestore()"/></p>
  <div class="menu_body"><a href='museum_articles.php?id=10''><img src='images/menu_arrow.png' border=0>&nbsp;Πληροφορίες</a><a href='museum_articles.php?id=7''><img src='images/menu_arrow.png' border=0>&nbsp;Αίθουσα Α</a><a href='museum_articles.php?id=8''><img src='images/menu_arrow.png' border=0>&nbsp;Αίθουσα Β</a><a href='museum_articles.php?id=9''><img src='images/menu_arrow.png' border=0>&nbsp;Αίθουσα Γ</a></div>
          
          <p class="menu_head">            <a href="bibliography.php"><img src="images/menu/menu7on.png" name="ImageM7" width="332" height="40" border="0" alt="αρχαια μεσσηνη"></a>
          </p>
          
          <p class="menu_head">          <a href="publications.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM81','','images/menu/menu8on.png',1)"><img src="images/menu/menu8.png" name="ImageM81" width="332" height="41" border="0" id="ImageM81" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="news.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM91','','images/menu/menu9on.png',1)"><img src="images/menu/menu9.png" name="ImageM91" width="332" height="40" border="0" id="ImageM91" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="video.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM92','','images/menu/video_on.png',1)"><img src="images/menu/video.png" name="ImageM92" width="332" height="40" border="0" id="ImageM92" alt="αρχαια μεσσηνη" /></a>
          </p>
          
  <p class="menu_head">          <a href="management.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM101','','images/menu/menu10on.png',1)"><img src="images/menu/menu10.png" name="ImageM101" width="332" height="40" border="0" id="ImageM101" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="contests.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM111','','images/menu/menu11on.png',1)"><img src="images/menu/menu11.png" name="ImageM111" width="332" height="40" border="0" id="ImageM111" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="newsletter.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM121','','images/menu/menu12on.png',1)"><img src="images/menu/menu12.png" name="ImageM121" width="332" height="40" border="0" id="ImageM121" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="contact.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM131','','images/menu/menu13on.png',1)"><img src="images/menu/menu13.png" name="ImageM131" width="332" height="44" border="0" id="ImageM131" alt="αρχαια μεσσηνη" /></a>
  </p>
         
        
</div></td>
      </tr>
      <tr>
        <td colspan="4" class="td_menu"><style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
<table width="324" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><a href="monuments_gallery.php"><img src="images/monuments_gallery.png" alt="αρχαια μεσσηνη" width="332" height="117" border="0" /></a></td>
  </tr>
  <tr>
    <td><a href="museum_gallery.php"><img src="images/museum_gallery.png" alt="αρχαια μεσσηνη" width="332" height="113" border="0" /></a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="padding-left:80px"><table border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2" class="style1 txt"><div align="center"><strong>Εφαρμογή ψηφιακής ξενάγησης<br />
          (μέσω κινητού)</strong></div></td>
        </tr>
      <tr>
        <td colspan="2" style="padding-top:10px"><div align="center"><img src="images/messene_app.png" alt="ancient messene" width="154" height="47" /></div></td>
        </tr>
      <tr>
        <td style="padding-top:10px"><div align="center"><a href="http://itunes.apple.com/us/app/messene/id498466711?mt=8" target="_blank"><img src="images/app_store.png" alt="ancient messene" width="90" height="30" border="0" /></a></div></td>
        <td style="padding-top:10px"><div align="center"><a href="https://play.google.com/store/apps/details?id=gr.apt.messene.gr" target="_blank"><img src="images/android_market.png" alt="ancient messene" width="90" height="30" border="0" /></a></div></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</td>
      </tr>
      
    </table></td>
    <td width="628" valign="top" background="images/bg_content.png"><table width="628" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="628" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="309" background="images/ancientmessene_02.png"><script type="text/javascript">

/*** 
    Simple jQuery Slideshow Script
    Released by Jon Raasch (jonraasch.com) under FreeBSD license: free to use or modify, not responsible for anything, etc.  Please link out to me if you like it :)
***/

function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');

    // uncomment the 3 lines below to pull the images in random order
    
    // var $sibs  = $active.siblings();
    // var rndNum = Math.floor(Math.random() * $sibs.length );
    // var $next  = $( $sibs[ rndNum ] );


    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 5000 );
});

</script>

<style type="text/css">

/*** set the width and height to match your images **/

#slideshow {
    position:relative;
    height:309px;
	width:628px;
}

#slideshow IMG {
    position:absolute;
    top:0;
    left:0;
    z-index:8;
    opacity:0.0;
}

#slideshow IMG.active {
    z-index:10;
    opacity:1.0;
}

#slideshow IMG.last-active {
    z-index:9;
}
</style>
<div id="slideshow">
    <img src="content/slideshow/1.png" alt="Αρχαία Μεσσήνη" class="active" border="0" />
    <img src="content/slideshow/2.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/3.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/4.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/5.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/6.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/7.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/8.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/9.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/10.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/11.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/12.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/13.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/14.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/15.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/16.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/17.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/18.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/19.png" alt="Αρχαία Μεσσήνη" border="0" />
</div></td>
  </tr>
  <tr>
    <td><img src="images/ancientmessene_11.png" width="628" height="56" alt="αρχαια μεσσηνη" /></td>
  </tr>
</table>
</td>
      </tr>
      <tr>
        <td valign="top" class="content"><table width="555" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td class="txt"><div style="text-align: justify;">
	<div style="text-align: justify;">
		<strong>Ελληνόγλωσση Βιβλιογραφία:</strong></div>
	<div style="text-align: justify;">
		 </div>
	<div style="text-align: justify;">
		• Αναγνωστάκης Η. και Πούλου Ν., Η πρωτοβυζαντινή Μεσσήνη (5ος-7ος αιώνας) και προβλήματα της Χειροποίητης Κεραμικής στη Πελοπόννησο, Σύμμεικτα 11 (1997) 229-319.<br />
		 </div>
	<div style="text-align: justify;">
		• Γαλανού Αμ. και Δογάνη Ι., Ο Ερμής της Αρχαίας Μεσσήνης: Εφαρμογή τεχνολογίας Laser για απομάκρυνση ιζηματογενών αποθέσεων, Αρχαιολογία 85 (2002) 87-94.<br />
		 </div>
	<div style="text-align: justify;">
		• Γιαγκάκη Α., Γραπτή εφυαλωμένη κεραμική από την ανασκαφή της αρχαίας Μεσσήνης, ΔΧΑΕ περ. Δ, ΚΖ΄ (2006), 435-444.<br />
		 </div>
	<div style="text-align: justify;">
		• Γιαγκάκη, Α., Υστερορωμαϊκά πήλινα ενσφράγιστα "ιγδία" από την αρχαία Μεσσήνη, Βυζαντινός Δόμος 16 (2007-8), 35-67.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Yστερορωμαϊκή και Πρωτοβυζαντινή Mεσσήνη, στo Θέμελης Π. - Kόντη B. (εκδ.), Πρωτοβυζαντινή Mεσσήνη και Oλυμπία: Aστικός και αγροτικός χώρος στη Δυτική Πελοπόννησο, Πρακτικά του Διεθνούς Συμποσίου, Aθήνα 29-30 Mαΐου 1998, Aθήνα 2002, 20-58.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Πρώιμη ελληνιστική κεραμική από τη Μεσσήνη, στο ΣΤ’ Επιστημονικό Συνέδριο Ελληνικής Κεραμεικής, Βόλος 2004, 409-438, πίν. 183-194. &nbsp;<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., O Δαμοφών και η δραστηριότητά του στην Aρκαδία, στο Coulson W.D. and Palagia O. (εκδ.), Sculpture from Arcadia and Laconia, Proceedings of an International Conference, American School of Classical Studies at Athens 10-14 Αpril 1992, Oxford 1993, 99-109.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., O Δαμοφών στην Kύθνο, στο Mενδώνη Λ. και Mαζαράκης A. (εκδ.), Κέα- Kύθνος: Ιστορία και Αρχαιολογία, Aθήνα 1998. 437–448.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Tο Στάδιο της Mεσσήνης, στο Coulson W. and Kyrieleis H. (εκδ.), Πρακτικά Συμποσίου Oλυμπιακών Aγώνων 5-9 Σεπτεμβρίου 1988, Aθήνα 1992, 87-91, πίν. 38-55.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Αρχαία Μεσσήνη - Αρχαία Κορώνη (Βίοι Παράλληλοι), στο Ομηρική Αιπεία - Αρχαία Κορώνη - Πεταλίδι: Παρελθόν, Παρόν και Μέλλον. Πρακτικά Επιστημονικού Συνεδρίου, Αύγουστος 2005, Πεταλίδι 2009, 35-44.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Αρχαία Μεσσήνη, ο χώρος και τα μνημεία (Ειδική Έκδοση Περιφέρειας Πελοποννήσου), Αθήνα 1998.</div>
	<div style="text-align: justify;">
		• Θέμελης Π., Ήρωες και ηρώα στη Μεσσήνη, Αθήνα 2000.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Αρχαία Μεσσήνη: Μνημεία, χώρος, άνθρωποι (εκδόσεις ΜΙΛΗΤΟΣ), Αθήνα 2010.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Η Ανδανία και οι κώμες της Μεσσήνης, Μεσσηνιακά Χρονικά 4 (2008-2009), 1-8.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Η Αρχαία Μεσσήνη. Οδηγός του χώρου και του Μουσείου (έκδοση ΤΑΠΑ), Αθήνα 2003.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Η ελληνιστική κεραμική της Μεσσήνης, στο Ελληνιστική Κεραμική από την Πελοπόννησο, Αθήνα 2005, 95-106.<br />
		 </div>
	<div style="text-align: justify;">
		<a href="http://www.ancientmessene.gr/site/content/files/files/THEMELIS%202008%2C%20Krima%20peri%20Messinion%20kai%20Megalopolitwn.pdf" target="_blank"><img alt="" src="http://www.ancientmessene.gr/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" />• Θέμελης Π., Κρίμα περι Μεσσηνίων και Μεγαλοπολιτών, στο Πίκουλας Γ. (επιμ.), Ιστορίες για την Αρχαία Αρκαδία, Στεμνίτσα 2008, 211-222.</a><br />
		 </div>
	<div style="text-align: justify;">
		<a href="http://www.ancientmessene.gr/site/content/files/files/THEMELIS%202009%2C%20Messinias%20oinos%20kai%20Dionysos.pdf" target="_blank"><img alt="" src="http://www.ancientmessene.gr/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" /><br />
		• Θέμελης Π., Μεσσηνίας οίνος και Διόνυσος, στο Πίκουλας Γ. (εκδ.), Οίνον Ιστορώ ΙΧ, Αθήνα 2009, 93-113.</a><br />
		 </div>
	<div style="text-align: justify;">
		 </div>
	<div style="text-align: justify;">
		<a href="http://www.ancientmessene.gr/site/content/files/files/THEMELIS%202007%2C%20Karneia%20kai%20i%20Andania.pdf" target="_blank"><img alt="" src="http://www.ancientmessene.gr/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" />• Θέμελης Π., Τα Κάρνεια και η Ανδανία, στο Σημαντώνη-Μπουρνιά Ε., Λαιμού Α., Μενδώνη Λ. και Κούρου Ν. (εκδ.), Αμύμονα Έργα, Τιμητικός Τόμος για τον καθηγητή Βασίλη Κ. Λαμπρινουδάκη, Αθήνα 2007, 509-528.</a><br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Το Θέατρο της Μεσσήνης (εκδ. ΔΙΑΖΩΜΑ) Αθήνα 2010.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Το Πρόγραμμα της Ανασκαφής στην Αρχαία Μεσσήνη και η Δημοσίευση της, Ο Μέντωρ 60 (2001), 198-219.<br />
		 </div>
	<div style="text-align: justify;">
		• Θέμελης Π., Κόντη Β. (επιμ.), Πρωτοβυζαντινή Μεσσήνη και Ολυμπία: Αστικός και αγροτικός χώρος στη Δυτική Πελοπόννησο, Αθήνα 2002, 99-124.<br />
		 </div>
	<div style="text-align: justify;">
		• Ματθαίου Α., Δύο ιστορικές επιγραφές της Μεσσήνης, στο Mitsopoulos-Leon V. (εκδ.), Forschungen in der Peloponnes, Akten des Symposions anläßlich der Feier “100 Jahre Österreichisches Istitut Athen”, Athen 2001, 221-231.<br />
		 </div>
	<div style="text-align: justify;">
		• Μπαρδάνη Βούλα, Παλαιοχριστιανικές επιγραφές Μεσσήνης, στο Θέμελης Π., Κόντη Β.(επιμ.), Πρωτοβυζαντινή Μεσσήνη και Ολυμπία: Αστικός και αγροτικός χώρος στη Δυτική Πελοπόννησο, Αθήνα 2002, 82-98.<br />
		 </div>
	<div style="text-align: justify;">
		• Μπίρταχας Π., Μεσσήνη, το Ωδείο και το Ανατολικό Πρόπυλο, Αθήνα 2008.<br />
		 </div>
	<div style="text-align: justify;">
		• Μπίρταχας Π., Στερέωση-Αναστήλωση Ωδείου και Ανατολικού Προπύλου στο Ασκληπιείο της Αρχαίας Μεσσήνης, στο Χαρκιολάκης Ν. (επιμ.), Αποκατάσταση Μνημείων, Αναβίωση Ιστορικών Κτηρίων στην Πελοπόννησο, τομ. Α΄, Αθήνα 2008, 58-95.</div>
	<div style="text-align: justify;">
		 </div>
	<div style="text-align: justify;">
		• Πέννα B., Nομισματικές μαρτυρίες για τη βυζαντινή Mεσσηνία, Παμμεσσηνιακή-Aφιέρωμα, Aπρίλιος 1996, 7-13.<br />
		 </div>
	<div style="text-align: justify;">
		• Πέννα Β., Λαμπροπούλου Ά., Αναγνωστάκης Η., Γλυπτά μεταβατικών χρόνων από τη Βασιλική του Θεάτρου της αρχαίας Μεσσήνης, Πρακτικά Α΄Διεθνούς Συνεδρίου Βυζαντινής Γλυπτικής, Σεπτέμβριος 2000, Αθήνα 2008.<br />
		 </div>
	<div style="text-align: justify;">
		• Πούλου-Παπαδημητρίου Ν., Βυζαντινές πόρπες. Η περίπτωση της Μεσσήνης και της Ελεύθερνας, στο Θέμελης Π., Κόντη Β. (επιμ.), Πρωτοβυζαντινή Μεσσήνη και Ολυμπία: Αστικός και Αγροτικός χώρος στη Δυτική Πελοπόννησο, Αθήνα 2002, 125-136.<br />
		 </div>
	<div style="text-align: justify;">
		• Σιδηρόπουλος Kλ., Tα νομίσματα ως μάρτυρες της Mεσηνιακής ιστορίας, Παμμεσσηνιακή-Aφιέρωμα, Aπρίλιος 1996, 1-7.<br />
		 </div>
	<div style="text-align: justify;">
		• <a href="/site/content/files/files/Messene(1).pdf">Σιδηρόπουλος Κλ., Η νομισματική κυκλοφορία στην υστερορωμαϊκή και πρωτοβυζαντινή Μεσσήνη:</a><a href="/site/content/files/files/Messene(1).pdf"> </a><a href="/site/content/files/files/Messene(1).pdf" target="_blank"><img alt="" src="/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" /></a><a href="/site/content/files/files/Messene(1).pdf">Τυπικό παράδειγμα ή ιστορική εξαίρεση; στο Θέμελης Π., Κόντη Β. (επιμ.), Πρωτοβυζαντινή Μεσσήνη </a><a href="/site/content/files/files/Messene(1).pdf">και Ολυμπία: Αστικός και Αγροτικός χώρος στη Δυτική Πελοπόννησο, Αθήνα 2002, 99-124.&nbsp;</a></div>
	<div style="text-align: justify;">
		 </div>
	<div style="text-align: justify;">
		<a href="/site/content/files/files/Messene(1).pdf" target="_self"> </a></div>
	<div style="text-align: justify;">
		 </div>
	<div style="text-align: justify;">
		• Χλέπα Ε.-Α., Η Αρκαδική Πύλη του τείχους της Αρχαίας Μεσσήνης: Εργασίες Αποκατάστασης-Αναστήλωσης, στο Χαρκιολάκης Ν. (επιμ.), Αποκατάσταση Μνημείων, Αναβίωση Ιστορικών Κτηρίων στην Πελοπόννησο, τομ. Α΄, Αθήνα 2008, 30-57.<br />
		 </div>
	<p>
		• Χλέπα Ε.-Α., Μεσσήνη, το Αρτεμίσιο και οι Οίκοι της Δυτικής Πτέρυγας του Ασκληπιείου, Αθήνα 2001.</p>
	<p>
		 </p>
	<hr />
	<br />
	<br />
	<strong>Ξενόγλωσση Βιβλιογραφία:</strong></div>
<div style="text-align: justify;">
	 </div>
<div style="text-align: justify;">
	• Auberger J., Pausanias et les Messéniens: une histoire d’amour, REA 94 (1992), 187 – 19.<br />
	 </div>
<div style="text-align: justify;">
	• Baldassarra D., Famiglie aristocratiche di Messene in epoca imperiale (Tesi di Laurea, Universita di Venezia), 1999.<br />
	 </div>
<div style="text-align: justify;">
	• Barr-Sharrar B., A Plakettenvase from Ancient Messene, in Κερμάτια Φιλίας, Τιμητικός τόμος για τον Ιω. Τουράτσογλου, Αθήνα 2009, τομ. Β., 441-449.<br />
	 </div>
<div style="text-align: justify;">
	• Bauslaugh R.A., Messenian Dialect and Dedications of the Methanioi, Hesperia 59 (1990), 661-668.<br />
	 </div>
<div style="text-align: justify;">
	• Biagetti Cl., La Messenia e gli Eraclidi, La Parola del Passato CCCLXIX (2009), 411-451.<br />
	 </div>
<div style="text-align: justify;">
	• Böhringer D., Heroenkulte in Griechenland von der geometrischen bis zur klassischen Zeit. Attika, Argolis, Messenien, Freiburg 1998 (Dissertation). &nbsp;<br />
	 </div>
<div style="text-align: justify;">
	• Bourbou Chr., The People of Early Byzantine Eleutherna and Messene (6th-7th c.) A bioarchaeological approach, Athens 2004.<br />
	 </div>
<div style="text-align: justify;">
	• Broucke P.B.F.J., The Heroon at Messene: New Observations on Order, Style, and Date, Paper Delivered at the Annual Meeting of the Archaeological Institute of America, Montréal.(6-8/01).<br />
	 </div>
<div style="text-align: justify;">
	• Cooper F. A. &amp; Fortenberry D., The Heroon at Messene, AJA 97 (1993), 337.<br />
	 </div>
<div style="text-align: justify;">
	• Cooper F., Scamilli Impares and the Heroon at Messene, στο Haselberger L. (ed.), Appearance and Essence Refinements of Classical Architecture-Curvature, Philadelphia 1997, 97-112.<br />
	 </div>
<div style="text-align: justify;">
	• Cooper Fr., Reconstruction and Design of the Heroon at Messene, στο Ito J. (ed.), Symposium for International Collaborative Studies on Ancient Messene, Kumamoto 2002, 40-43.<br />
	 </div>
<div style="text-align: justify;">
	• Deligiannakis G., Two Late-Antique statues from ancient Messene, BSA 100 (2005), 387-406.<br />
	 </div>
<div style="text-align: justify;">
	• Deshours N., Cultes de Déméter, d’ Artémis Ortheia et culte impérial à Messène (Ier s. av. notre ére-Ier s. de notre ére), ZPE 146 (2004), 115-127.<br />
	 </div>
<div style="text-align: justify;">
	• Deshours N., La légende et le culte de Messène ou comment forger l’identité d’ une cité, REG 106(1993), 39 – 60.<br />
	 </div>
<div style="text-align: justify;">
	• Deshours N., Les institutions civiques de Messène à l’époque hellénistique tardive, ZPE 150, 134–146.<br />
	 </div>
<div style="text-align: justify;">
	• Deshours N., Les Messéniens, le règlement des Mystères et la consultation de l’ oracle d’ Apollon Pythéen à Argos, REG 112 (1999), 463-484.<br />
	 </div>
<div style="text-align: justify;">
	• Deshours N., Les Mystères d’ Andania. Ėtude d’épigraphieet d’histoire religieuse (Ausonius Scripta Antiqua 16), Bordeaux 2006.<br />
	 </div>
<div style="text-align: justify;">
	• Felten Fl. και Reinholdt Cl., Das Brunnenhaus der Arsinoe in Messene, στο Mitsopoulos-Leon V. (ed.), Forschungen in der Peloponnes. Akten des Symposions anläßlich der Feier “100 Jahre Österreichisches Istitut Athen”, Athen 2001, 307–323.<br />
	 </div>
<div style="text-align: justify;">
	• Figueira T., The Evolution of the Messenian Identity, in Hodkinson S. and Powell A. (eds.), Sparta: New Pespectives, London 1999, 227 κ.ε.<br />
	 </div>
<div style="text-align: justify;">
	• Fröhlich P., Les institutions des cités de Messénie à la basse époque hellénistique, in Renard J. (ed.), Le Péloponnèse. Archéologie et histoire, Rennes 1999, 229 -242.&nbsp;<br />
	 </div>
<div style="text-align: justify;">
	• Grandjean C., Contremarques et monnaies messèniennes et spartiates des débutes du principat, BSFN 47 (1992), 298-301.<br />
	 </div>
<div style="text-align: justify;">
	• Grandjean C., La question de l’Ėtat messénien, REG 115 (2002), 538–560.<br />
	 </div>
<div style="text-align: justify;">
	• Grandjean C., Les Messéniens de 370/369 au Ier siècle de notre ère. Monnayages et histoire (BCH Suppl. 44), Athènes–Paris 2003.<br />
	 </div>
<div style="text-align: justify;">
	• Grandjean C., Monnaies et circulation monétaire à Messène du second siècle av. J.C. au premier siècle ap. J.C., Topoi 7/1 1997, 115-122.<br />
	 </div>
<div style="text-align: justify;">
	• Habicht Chr., Neues aus Messene, ZPE 130 (2000) 121–126.<br />
	 </div>
<div style="text-align: justify;">
	• Habicht Chr., Zwei Familien aus Messene, ZPE 115 (1997), 125-127.<br />
	 </div>
<div style="text-align: justify;">
	• Hayashida Y., Survey and Reconstruction of the Asklepieion at Messene, στο Ito J. (ed.), Symposium for International Collaborative Studies on Ancient Messene, Kumamoto 2002, 31-40.<br />
	 </div>
<div style="text-align: justify;">
	• Hoepfner W., Der Stadtplan von Messene, AAA 35-38 (2002-2005), 223-228.<br />
	 </div>
<div style="text-align: justify;">
	• Ito J., Architectural Studies of the three Grave Monuments in the Gymnasium Complex at Ancient Messene, Kumamoto 2002.<br />
	 </div>
<div style="text-align: justify;">
	• Ito J., Survey and Reconstruction of the Grave Monuments at Messene, στο Ito J. (ed.), Symposium for International Collaborative Studies on Ancient Messene, Kumamoto 2002, 1-10.<br />
	 </div>
<div style="text-align: justify;">
	• Katsumata T., Sculptures from the Grave Monument K1, στο: Ito J. (ed.), Symposium for International Collaborative Studies on Ancient Messene, Kumamoto 2002, 10-15.<br />
	 </div>
<div style="text-align: justify;">
	• Luraghi N., Becoming Messenian, JHS 122 (2002), 45-69.<br />
	 </div>
<div style="text-align: justify;">
	• Luraghi N., Messenian Kulte und messenische Identität im hellenistischer Zeit, in Funke P. &amp; Haake M. (eds.), Kult Politik–Ethnos: Überregionale Heiligtümer im Spannungsfeld von Kult und Politik, Historia Eizalschriften 189, 2006, 169-196.<br />
	 </div>
<div style="text-align: justify;">
	• Luraghi N., Pausania e I Messenii: interpretazioni minime, RFIC (2005) 133, 177-201.<br />
	 </div>
<div style="text-align: justify;">
	• Luraghi N., Pausania e la fondatione di Messene sullo Stretto, note di lettura, RFIC 122 (1994), 140-151.<br />
	 </div>
<div style="text-align: justify;">
	• Luraghi, N., Messenian Ethnicity and the Free Messenians, in Funke P., and Luraghi N. (eds.), The Politics of Ethnicity and the Crisis of the Peloponnesian League, Cambridge 2009, 110-134.</div>
<div style="text-align: justify;">
	 </div>
<div style="text-align: justify;">
	• Maggi S., Sul tempio di Messene a Messene, Athenaeum 84 (1996), 260-265.<br />
	 </div>
<div style="text-align: justify;">
	• Migeotte L., La date de l’oktôbolos eisphora de Messène, Topoi 7/1 (1997), 51-61.<br />
	 </div>
<div style="text-align: justify;">
	• Morizot Y., Artémis Limnatis, sanctuaires et functions, στο Docter R.F. &amp; Moormann E.M. (εκδ.), Classical Archaeology towards the Third Millenium: Reflections and Perspectives, Proceedings of the XV the International Congress of Classisal Archaeology, Amsterdam, July 12-17 1998, Amsterdam 1999 (Allard Pierson Series 12 ), 270 – 272.<br />
	 </div>
<div style="text-align: justify;">
	• Morizot Y., Le hiéron de Messènè, BCH 118 (1994), 399-405.<br />
	 </div>
<div style="text-align: justify;">
	• Müth S., Eigene Wege. Topographie und Stadtplan von Messene in spätklassisch-hellenistischer Zeit, Rahden 2007.<br />
	 </div>
<div style="text-align: justify;">
	• Müth-Herda S., Street Network and Town Planning of Ancient Messene, in Ito J. (ed.), Symposium for International Collaborative Studies on Ancient Messene, Kumamoto 2002, 16-30.<br />
	 </div>
<div style="text-align: justify;">
	• Müth-Herda S., Messene: Topographie und Stadtplan in spätklassischer und hellenistischer Zeit (Dissertation), Berlin 2005.<br />
	 </div>
<div style="text-align: justify;">
	• Nobis G., Archäozoologische Studien an Tierresten aus Alt-Messene/Ithome (SW-Peloponnes, Griechenland), Grabungen 1992 bis 1996, in Buitenhuis H., Prummel W., Animals and Man in the Past: Essays in honour of Dr. A. T. Clason emeritus professor of archaeozoology Rijksuniversiteit Groningen, the Netherlands, Groningen 2001, 95-121.<br />
	 </div>
<div style="text-align: justify;">
	• Nobis G., Tieropfer aus einem Heroen-und Demeterheiligtum des antiken Messene (SW-Peloponnes, Griechenland), Grabungen 1992 bis 1996, Tier und Museum 5.4 (1997), 97-111.<br />
	 </div>
<div style="text-align: justify;">
	• Nobis, G., Die Tierreste aus dem antiken Messene: Grabung 1990/91, στο Kokabi M., Wahl J. (εκδ.), Beiträge zur Archäozoologie und Prähistorischen Anthropologie, Forschungen und Berichte zur Vor- und Frügeschichte in Baden-Württemberg 53, Stuttgart 1994, 297-313.<br />
	 </div>
<div style="text-align: justify;">
	• Reinholdt Cl., Das Brunnenhaus der Arsinoë in Messene, Wien 2009.<br />
	 </div>
<div style="text-align: justify;">
	• Sève M., Le dossier épigraphique du sculpteur Damophon de Messène, Ktema 33 (2008), 117-128.<a href="/site/content/files/files/Kl.Sidiropoulos Glasgow 2009.pdf" target="_blank"><img alt="" src="http://ancientmessene.gr/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" /></a><br />
	 </div>
<div style="text-align: justify;">
	• <a href="/site/content/files/files/Kl.Sidiropoulos%20Glasgow%202009.pdf" target="_self">Sidiropoulos Kl., A hoard of denarii and early roman Messene, Proceedings of XVI Int. Num</a><a href="/site/content/files/files/Kl.Sidiropoulos%20Glasgow%202009.pdf" target="_self">ismati</a><a href="/site/content/files/files/Kl.Sidiropoulos%20Glasgow%202009.pdf" target="_self">c</a><a href="/site/content/files/files/Kl.Sidiropoulos%20Glasgow%202009.pdf" target="_self"> </a><a href="/site/content/files/files/Kl.Sidiropoulos%20Glasgow%202009.pdf" target="_self">Congress, Glasgow 2009, 1025-36.</a></div>
<div style="text-align: justify;">
	 </div>
<div style="text-align: justify;">
	• Sineux P., Á propos de l’ Asclépieion de Messène: Asclépios poliade et guérisseur, REG 110 (1997), 1-24.<br />
	 </div>
<div style="text-align: justify;">
	• Sioumpara Ε., Der Asklepiostempel von Messene auf der Peloponnes. Untersuchungen zur hellenistischen Tempelarchitektur (Dissertation), 2011.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Architectural Terracottas from Messene, in Winters N.A (ed.), Proceedings of the International Conferrence on Greek Architectural Terracottas of the Classical and Hellenistic Periods, Athens, December 12-15, 1991, Hesperia Supplement 27 (1994), 141-169, pl. 48-56.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Artemis Ortheia at Messene, the Epigraphical and the Archaeological Evidence, in Hägg R. (ed.), Ancient Greek Cult Practice from the Epigraphical Evidence, International Seminar at the Swedish Institute at Athens 22-24 November 1991, Stockholm 1994, 101-122.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Bourbou Chr., Child Burials from Messene, in Morizot Y. (ed.), L'enfant et le mort dans l'antiquité, Paris 2011.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Cults on Mount Ithome, Kernos 17 (2004), 143-154.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Damophon of Messene. New Evidence, in Sheedy K. (ed.), Archaeology in the Peloponnese. New Excavations and Research, Oxford 1994, 1-37.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Damophon von Messene: Sein Werk im Lichte der neuen Ausgrabungen, AntK 36 (1993) 24-40.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Damophon, in Palagia O. and Pollitt J.J. (eds.), Personal Styles in Greek Sculpture (YCS 30), Cambridge 1996, 154-187.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Das Gymnasion von Messene in der römischen Zeit, in Reusser Chr. (ed.), Griechenland in der Kaiserzeit, Neue Funde und Forschungen zu Skulptur, Architektur und Topographie, Bern 2001, 9-20.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Das Stadion und das Gymnasion von Messene, Nikephoros 22 (2010).<br />
	 </div>
<div style="text-align: justify;">
	<a href="http://ancientmessene.gr/site/content/files/files/THEMELIS%202010%2C%20Die%20Agora%20von%20Messene%2C%20Festschrift%20Wesenberg%20%282010%29.pdf" target="_blank"><img alt="" src="http://ancientmessene.gr/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" />• Themelis P., Die Agora von Messene,&nbsp;in H. Frielinghaus and J. Stroszeck (ed.), Neue Forschungen zu griechischen Städten und Heiligtümern, Festschrift für Burkhardt Wesenberg, Möhnesee-Warmel 2010.</a><br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Die Statuenfunde aus dem Gymnasion von Messene, NüBlA 15(1998/99, 2000), 59-84.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Messene, Recent Discoveries (Sculpture), in Stamatopoulou M. – Yeroulanou M. (eds.), Excavating Classical Culture: Recent Archaeological Discoveries in Greece, Oxford 2002, 229-243.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., Monuments guerriers de Messéne, in Frei-Stolba R. and Gex K. (eds.), Recherches récents sur le monde hellénistique, Actes du colloque en l’honneur de Pièrre Ducrey, Lausanne 20-21 Nov. 1998, Bern 2001, 199-216.<br />
	 </div>
<div style="text-align: justify;">
	<a href="http://ancientmessene.gr/site/content/files/files/THEMELIS%202001%2CRoman%20Messene.pdf" target="_blank"><img alt="" src="http://ancientmessene.gr/site/content/files/images/pdf-icon.gif" style="width: 48px; height: 48px; float: right;" />• Themelis P., Roman Messene The Gymnasium, in Salomies O. (εκδ.), The Greek East in the Roman Context, Proceedings of a Colloquium organized by the Finnish Institute at Athens May 21 and 22, 1999, Helsinki 2001, 119 – 126. </a><br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., The cult of Isis in Ancient Messene, in Veymiers R. (ed.), IVe Colloque International sur les Études Isiaques, Liège 2011.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., The Economy and Society of Messenia under Roman Rule, in A.D. Rizakis (ed.), Roman Peloponnese III. Society, Economy and Cultutre in the Imperial Roman Order: Continuity and Innovation, Meletemata XX, Athens 2010.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., The Messene Theseus and the Ephebes, in Buzzi S. et alii (eds.), Zona Archaeologica, Festschrift für Hans Peter Isler zum 60. Geburstag, Bonn 2001, 407-419.<br />
	 </div>
<div style="text-align: justify;">
	• Themelis P., The Sanctuary of Demeter and the Dioscouroi at Messene, in Hägg R. (ed.), Ancient Greek Cult Practice from the Archaeological Evidence, International Seminar held at the Swedish Institute at Athens 22-24 October 1993, Stockholm 1998, 157-186.<br />
	 </div>
<div style="text-align: justify;">
	• Toma N.-M., Die Bauornamentik der Stoen des Asklepieions von Messene. Zur Typologie, chronologischen Einordnung unf Funktion der Figuralkapitelle, Berlin 2006 (Magisterarbeit).<br />
	 </div>
<div style="text-align: justify;">
	• Torelli M., L’Asklepieion di Messene , lo scultore Damofonte e Pausania, in Capecchi G. (eds.), In Μemoria di Enrico Pariboni vol. ΙΙ, Archaelogica 125, Roma 1998, 465–483.<br />
	 </div>
<div style="text-align: justify;">
	• Tsivikis N., Considerations on some Bronze Buckles from Byzantine Messene, in B. Böhlendorf-Arslan (ed.), Byzantinische Kleinfunde im Archäologischen Kontext, DAII, Constantinople 2011.<br />
	 </div>
<div style="text-align: justify;">
	• Zunino M.L., Hiera Messeniaka, Udine 1997.</div>            </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  <tr>
    <td colspan="2"><table width="960" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="footer">Copyright © 2013 Εταιρεία Μεσσηνιακών Αρχαιολογικών Σπουδών - All rights reserved.</td>
  </tr>
</table>
<div style="text-indent:-9999px; position:fixed">
<a href="http://www.elektroniksigaraevi.us/elektronik-sigara/" title="Elektronik sigara">elektronik sigara</a>
</div></td>
  </tr>
</table>
</body>
</html>
