<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Ithome, Messene, Asclepieion, Asclepius, Stadion, Heroon, Mausoleum, Klepsydra, Arsinoe, Themelis, Ιθώμη, Μεσσήνη, Ασκληπιείο, Ασκληπιός, Στάδιο, Ηρώο, Μαυσωλείο, Κλεψύδρα, Αρσινόη, Θέμελης">
<meta name="description" content="Ancient Messene counts among the most important excavated cities in Greece. It comprises monumental public buildings, sanctuaries, grave monuments and mighty fortifications. Η Αρχαία Μεσσήνη περιλαμβάνεται ανάμεσα στις σημαντικότερες ανασκαμμένες πόλεις της Ελλάδας και περιλαμβάνει μνημειώδη δημόσια οικοδομήματα, ιερά, ταφικά μνημεία και πανίσχυρες οχυρώσεις. ">
<META name="robots" content="all">
<META name="robots" content="index,follow">
<title>Ithome, Messene, Asclepieion, Asclepius, Stadion, Heroon, Mausoleum, Klepsydra, Arsinoe, Themelis, Ιθώμη, Μεσσήνη, Ασκληπιείο, Ασκληπιός, Στάδιο, Ηρώο, Μαυσωλείο, Κλεψύδρα, Αρσινόη, Θέμελης</title><link href="styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-1.4.3.min.js"></script>

</head>
<style>
a:link {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px;	color: #000000;}
a:visited {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px;	color: #000000;}
a:hover {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px; color: #9A8A66;}
a:active {
font-family: Verdana, Arial, Helvetica, sans-serif; 
font-size:12px;	color: #000000;}
</style>
<body>
<table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" class="td_menu"><table width="332" border="0" cellspacing="0" cellpadding="0">
           <tr>
        <td colspan="4"><table width="332" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="4"><img src="images/ancientmessene_01_en.png" alt="αρχαια μεσσηνη" width="332" height="122" border="0" usemap="#Map" />
      <map name="Map" id="Map">
        <area shape="rect" coords="57,38,320,104" href="index_en.php" />
      </map></td>
  </tr>
  <tr>
    <td><img src="images/ancientmessene_03.png" width="59" height="36" alt="αρχαια μεσσηνη"/></td>
    <td><a href="/video.php"><img src="images/ancientmessene_04.png" width="35" height="36" alt="αρχαια μεσσηνη" border="0"/></a></td>
    <td><a href="/video_en_en.php"><img src="images/ancientmessene_05.png" width="37" height="36" alt="αρχαια μεσσηνη" border="0"/></a></td>
    <td><img src="images/ancientmessene_06.png" width="201" height="36" alt="αρχαια μεσσηνη"/></td>
  </tr>
</table>

</td>
      </tr>
      <tr>
        <td colspan="4" class="td_menu">
<script type="text/javascript">
<!--//---------------------------------+
//  Developed by Roshan Bhattarai 
//  Visit http://roshanbh.com.np for this script and more.
//  This notice MUST stay intact for legal use
// --------------------------------->
$(document).ready(function()
{
	$("#firstpane p.menu_head").click(function()
    {
		$(this).css({backgroundImage:"url(down.png)"}).next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
       	$(this).siblings().css({backgroundImage:"url(left.png)"});
	});

});
 

</script>
<style type="text/css">

.menu_list {	
	width: 260px;
	
}
.menu_head {
	cursor: pointer;
	position: relative;
	margin:0px;


}

.menu_head1 {
	cursor: pointer;
	position: relative;
	margin:0px;
    font-weight:bold;
	background-image: url(images/bg_menu_buttons_.png);
	background-repeat:no-repeat;
}
.menu_body {
	display:none;
	width: 260px; padding-left:60px; padding-bottom:20px
	
}
.menu_body a{
  display:block;
color:#ffffff;
font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:12px;
font-weight:bold;
-webkit-transition-property:color, text;
-webkit-transition-duration: 0.2s, 0.2s;
-webkit-transition-timing-function: linear, ease-in;

-moz-transition-property:color, text;
-moz-transition-duration:0.2s;
-moz-transition-timing-function: linear, ease-in;

-o-transition-property:color, text;
-o-transition-duration:0.2s;
-o-transition-timing-function: linear, ease-in;
}
.menu_body a:hover{
color: #CCCCCC;
  }
  
</style>
  <script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body><div>
<div id="firstpane" class="menu_list"> <!--Code for menu starts here-->
<p class="menu_head1">          <a href="messenian_history_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM14','','images/menu_en/menu1on.png',1)"><img src="images/menu_en/menu1.png" name="ImageM14" width="332" height="50" border="0" id="ImageM14" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="history_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM21','','images/menu_en/menu2on.png',1)"><img src="images/menu_en/menu2.png" name="ImageM21" width="332" height="40" border="0" id="ImageM21" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="the-site_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM31','','images/menu_en/menu3on.png',1)"><img src="images/menu_en/menu3.png" name="ImageM31" width="332" height="38" border="0" id="ImageM31" alt="αρχαια μεσσηνη" /></a>
          </p>
          
  <p class="menu_head"><img src="images/menu_en/menu4.png" alt="αρχαια μεσσηνη" name="Image00" width="332" height="40" border="0" onMouseOver="MM_swapImage('Image00','','images/menu_en/menu4on.png',1)" onMouseOut="MM_swapImgRestore()"/></p>
  <div class="menu_body"><a href='monuments_articles_en.php?id=12''><img src='images/menu_arrow.png' border=0>&nbsp;The Theater - The Arsinoe fountain house</a><a href='monuments_articles_en.php?id=18''><img src='images/menu_arrow.png' border=0>&nbsp;Agora - Sanctuary of Demetra &amp; Dioskouroi</a><a href='monuments_articles_en.php?id=13''><img src='images/menu_arrow.png' border=0>&nbsp;The Asclepieion</a><a href='monuments_articles_en.php?id=19''><img src='images/menu_arrow.png' border=0>&nbsp;The Cross Road - The Hierothysion</a><a href='monuments_articles_en.php?id=15''><img src='images/menu_arrow.png' border=0>&nbsp;The Stadium and Gymnasium - Heroon</a><a href='monuments_articles_en.php?id=14''><img src='images/menu_arrow.png' border=0>&nbsp;The Sanctuaries of Ithomi</a><a href='monuments_articles_en.php?id=22''><img src='images/menu_arrow.png' border=0>&nbsp;Conservation</a></div>
          
  <p class="menu_head"><img src="images/menu_en/menu5.png" alt="αρχαια μεσσηνη" width="332" height="39" border="0" id="Image1" onMouseOver="MM_swapImage('Image1','','images/menu_en/menu5on.png',1)" onMouseOut="MM_swapImgRestore()" /></p>
  <div class="menu_body"><a href='findings_articles_en.php?id=11''><img src='images/menu_arrow.png' border=0>&nbsp;Sculpture of Ancient Messene (Damophon)</a><a href='findings_articles_en.php?id=9''><img src='images/menu_arrow.png' border=0>&nbsp;Contribution of inscriptions to the study of history of Ancient Messene</a><a href='findings_articles_en.php?id=10''><img src='images/menu_arrow.png' border=0>&nbsp;The coinage of Messene</a><a href='findings_articles_en.php?id=8''><img src='images/menu_arrow.png' border=0>&nbsp;The pottery of Messene</a><a href='findings_articles_en.php?id=12''><img src='images/menu_arrow.png' border=0>&nbsp;Conservation</a></div>
          
  <p class="menu_head"><img src="images/menu_en/menu6.png" alt="αρχαια μεσσηνη" width="332" height="40" border="0" id="Image2" onMouseOver="MM_swapImage('Image2','','images/menu_en/menu6on.png',1)" onMouseOut="MM_swapImgRestore()"/></p>
  <div class="menu_body"><a href='museum_articles_en.php?id=10''><img src='images/menu_arrow.png' border=0>&nbsp;Information</a><a href='museum_articles_en.php?id=7''><img src='images/menu_arrow.png' border=0>&nbsp;Hall A</a><a href='museum_articles_en.php?id=8''><img src='images/menu_arrow.png' border=0>&nbsp;Hall B</a><a href='museum_articles_en.php?id=9''><img src='images/menu_arrow.png' border=0>&nbsp;Hall C</a></div>
          
          <p class="menu_head">          <a href="bibliography_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM71','','images/menu_en/menu7on.png',1)"><img src="images/menu_en/menu7.png" name="ImageM71" width="332" height="40" border="0" id="ImageM71" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="publications_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM81','','images/menu_en/menu8on.png',1)"><img src="images/menu_en/menu8.png" name="ImageM81" width="332" height="41" border="0" id="ImageM81" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">          <a href="news_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM91','','images/menu_en/menu9on.png',1)"><img src="images/menu_en/menu9.png" name="ImageM91" width="332" height="40" border="0" id="ImageM91" alt="αρχαια μεσσηνη" /></a>
          </p>
          
          <p class="menu_head">            <a href="video_en.php"><img src="images/menu_en/video_on.png" name="ImageM9" width="332" height="40" border="0" alt="αρχαια μεσσηνη" /></a>
          </p>
          
  <p class="menu_head">          <a href="management_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM101','','images/menu_en/menu10on.png',1)"><img src="images/menu_en/menu10.png" name="ImageM101" width="332" height="40" border="0" id="ImageM101" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="newsletter_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM121','','images/menu_en/menu12on.png',1)"><img src="images/menu_en/menu12.png" name="ImageM121" width="332" height="40" border="0" id="ImageM121" alt="αρχαια μεσσηνη" /></a>
  </p>
          
          <p class="menu_head">          <a href="contact_en.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ImageM131','','images/menu_en/menu13on.png',1)"><img src="images/menu_en/menu13.png" name="ImageM131" width="332" height="44" border="0" id="ImageM131" alt="αρχαια μεσσηνη" /></a>
  </p>
         
        
</div></td>
      </tr>
      <tr>
        <td colspan="4" class="td_menu"><style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
<table width="324" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><a href="monuments_gallery_en.php"><img src="images/monuments_gallery_en.png" alt="αρχαια μεσσηνη" width="332" height="117" border="0" /></a></td>
  </tr>
  <tr>
    <td><a href="museum_gallery_en.php"><img src="images/museum_gallery_en.png" alt="αρχαια μεσσηνη" width="332" height="113" border="0" /></a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="padding-left:40px"><table width="211" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2" class="style1 txt"><div align="center"><strong>Virtual tour application<br />
          (mobile)</strong></div></td>
      </tr>
      <tr>
        <td colspan="2" style="padding-top:10px"><div align="center"><img src="images/messene_app_en.png" alt="ancient messene" width="154" height="47" /></div></td>
      </tr>
      <tr>
        <td style="padding-top:10px"><div align="center"><a href="http://itunes.apple.com/us/app/messene/id498466711?mt=8" target="_blank"><img src="images/app_store.png" alt="ancient messene" width="90" height="30" border="0" /></a></div></td>
        <td style="padding-top:10px"><div align="center"><a href="https://play.google.com/store/apps/details?id=gr.apt.messene.gr" target="_blank"><img src="images/android_market.png" alt="ancient messene" width="90" height="30" border="0" /></a></div></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</td>
      </tr>
      
    </table></td>
    <td width="628" valign="top" background="images/bg_content.png"><table width="628" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="628" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="309" background="images/ancientmessene_02.png"><script type="text/javascript">

/*** 
    Simple jQuery Slideshow Script
    Released by Jon Raasch (jonraasch.com) under FreeBSD license: free to use or modify, not responsible for anything, etc.  Please link out to me if you like it :)
***/

function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');

    // uncomment the 3 lines below to pull the images in random order
    
    // var $sibs  = $active.siblings();
    // var rndNum = Math.floor(Math.random() * $sibs.length );
    // var $next  = $( $sibs[ rndNum ] );


    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 5000 );
});

</script>

<style type="text/css">

/*** set the width and height to match your images **/

#slideshow {
    position:relative;
    height:309px;
	width:628px;
}

#slideshow IMG {
    position:absolute;
    top:0;
    left:0;
    z-index:8;
    opacity:0.0;
}

#slideshow IMG.active {
    z-index:10;
    opacity:1.0;
}

#slideshow IMG.last-active {
    z-index:9;
}
</style>
<div id="slideshow">
    <img src="content/slideshow/1.png" alt="Αρχαία Μεσσήνη" class="active" border="0" />
    <img src="content/slideshow/2.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/3.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/4.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/5.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/6.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/7.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/8.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/9.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/10.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/11.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/12.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/13.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/14.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/15.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/16.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/17.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/18.png" alt="Αρχαία Μεσσήνη" border="0" />
    <img src="content/slideshow/19.png" alt="Αρχαία Μεσσήνη" border="0" />
</div></td>
  </tr>
  <tr>
    <td><img src="images/ancientmessene_11.png" width="628" height="56" alt="αρχαια μεσσηνη" /></td>
  </tr>
</table>
</td>
      </tr>
      <tr>
        <td valign="top" class="content"><table width="555" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td class="txt"><div>
	• A trip to Ancient Messene</div>
<div>
	 </div>
<div style="text-align: center;">
	<iframe allowfullscreen="" frameborder="0" height="281" src="http://www.youtube.com/embed/De8KRYx-U00?rel=0" width="500"></iframe></div>
<div>
	 </div>
<div>
	 </div>
<div>
	<img alt="" src="/site/content/files/images/play.png" style="width: 25px; height: 19px; float: left; margin: 2px;" /><a href="http://www.blod.gr/lectures/Pages/viewlecture.aspx?LectureID=360" target="_blank">• Lecture of Prof. P.Themelis, Ancient Messene: Before and after, in Megaron plus (28/2/2012) </a><br />
	<br />
	 </div>
<div>
	• European Union Prize for Cultural Heritage / Europa Nostra Awards 2011</div>
<p style="text-align: center;">
	<iframe allowfullscreen="" frameborder="0" height="284" src="http://www.youtube.com/embed/e-cnSvkNR2c" width="500"></iframe></p>
<p style="text-align: center;">
	 </p>
<div>
	• Interview of Prof. P.Themelis (11/10/2008)</div>
<div>
	 </div>
<p style="text-align: center;">
	<iframe allowfullscreen="" frameborder="0" height="369" src="http://www.youtube.com/embed/knjYImRIbjo" width="500"></iframe></p>
<p style="text-align: center;">
	 </p>
<div>
	• Recitation of Lyd. Koniordou in Ekklesiasterion of Messene (11/10/2008)</div>
<div>
	 </div>
<p style="text-align: center;">
	<iframe allowfullscreen="" frameborder="0" height="369" src="http://www.youtube.com/embed/2XE14R74SnQ" width="500"></iframe></p>            </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  <tr>
    <td colspan="2"><table width="960" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="footer">Copyright © 2013 Society Of Messenian Archaeological Studies - All rights reserved.</td>
  </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
