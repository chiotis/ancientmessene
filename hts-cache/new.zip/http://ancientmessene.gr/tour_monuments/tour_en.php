<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<script type="text/javascript" src="googleapis.js"></script>
		<script type="text/javascript" src="js/jquery.transform-0.9.3.min_.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
		<script type="text/javascript" src="js/jquery.zoomtour.js"></script>
		<script type="text/javascript">
			$(function() {
				$('#zt-container').zoomtour({
				 rotation        : false
				});
			});
		</script>

		<link rel="stylesheet" type="text/css" href="css/style.css" />
<noscript>
			<link rel="stylesheet" type="text/css" href="css/styleNoJS.css" />
		</noscript>
<div>
    <table border="0" align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px"><strong>"Walk" in Ancient Messene by clicking the icons </strong></td>
        <td><img src="images/camera1.png" alt="camera" width="30" height="30" /></td>
      </tr>
  </table>
</div>
<div id="zt-container" class="zt-container">

	<div class="zt-item" data-id="zt-item-1">
		<img src="images/index_en.jpg" width="1000" height="667" class="zt-current" />
<!-- stadio -->	  
      <div class="zt-tag" data-dir="1" data-link="zt-item-11" data-zoom="5" data-speed="500" data-delay="50" style="top:200px;left:120px;width:30px;height:30px;"></div>
<!-- hrwo-->	      
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-1" data-zoom="5" data-speed="500" data-delay="50" style="top:220px;left:50px;width:30px;height:30px;"></div>
<!-- iseio -->	      
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-2" data-zoom="5" data-speed="500" data-delay="50" style="top:190px;left:810px;width:30px;height:30px;"></div>
<!-- palaistra -->
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-3" data-zoom="5" data-speed="500" data-delay="50" style="top:90px;left:160px;width:30px;height:30px;"></div>
<!-- agora -->    
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-4" data-zoom="5" data-speed="500" data-delay="50" style="top:310px;left:760px;width:30px;height:30px;"></div>
<!-- arsinoh -->    
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-5" data-zoom="5" data-speed="500" data-delay="50" style="top:280px;left:860px;width:30px;height:30px;"></div>	
<!-- vasilikh -->
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-6" data-zoom="5" data-speed="500" data-delay="50" style="top:200px;left:730px;width:30px;height:30px;"></div>	 
<!-- rwmaikh vila -->
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-7" data-zoom="5" data-speed="500" data-delay="50" style="top:435px;left:350px;width:30px;height:30px;"></div> 
<!-- villa stadiou -->
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-8" data-zoom="5" data-speed="500" data-delay="50" style="top:220px;left:380px;width:30px;height:30px;"></div>    
<!-- theatro -->
      <div class="zt-tag" data-dir="1" data-link="zt-item-11-9" data-zoom="5" data-speed="500" data-delay="50" style="top:185px;left:855px;width:30px;height:30px;"></div>      
<!--ag.nikolaos--><div class="zt-tag" data-dir="1" data-link="zt-item-11-9-9" data-zoom="5" data-speed="500" data-delay="50" style="top:90px;left:940px;width:30px;height:30px;"></div> 
<!--asklipieio-->
       <div class="zt-tag" data-dir="1" data-link="zt-item-11-10" data-zoom="5" data-speed="500" data-delay="50" style="top:280px;left:530px;width:30px;height:30px;"></div>    
       <div class="zt-tag" data-dir="1" data-link="zt-item-11-11" data-zoom="5" data-speed="500" data-delay="50" style="top:340px;left:540px;width:30px;height:30px;"></div>    
       <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-18" data-zoom="5" data-speed="500" data-delay="50" style="top:500px;left:540px;width:30px;height:30px;"></div>    

    
    </div>

<!--ASKLIPIEIO-->
<div class="zt-item" data-id="zt-item-11-10">
		<img class="zt-current" src="images/asklipieio/1.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11">
		<img class="zt-current" src="images/asklipieio/00.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-1" data-zoom="5" data-speed="500" data-delay="50" style="top:310px;left:120px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-2" data-zoom="5" data-speed="500" data-delay="50" style="top:150px;left:160px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-3" data-zoom="5" data-speed="500" data-delay="50" style="top:290px;left:190px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-4" data-zoom="5" data-speed="500" data-delay="50" style="top:400px;left:100px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-5" data-zoom="5" data-speed="500" data-delay="50" style="top:490px;left:550px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-6" data-zoom="5" data-speed="500" data-delay="50" style="top:440px;left:700px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-7" data-zoom="5" data-speed="500" data-delay="50" style="top:395px;left:410px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-8" data-zoom="5" data-speed="500" data-delay="50" style="top:380px;left:160px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-9" data-zoom="5" data-speed="500" data-delay="50" style="top:370px;left:750px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-10" data-zoom="5" data-speed="500" data-delay="50" style="top:530px;left:310px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-11" data-zoom="5" data-speed="500" data-delay="50" style="top:450px;left:260px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-12" data-zoom="5" data-speed="500" data-delay="50" style="top:470px;left:300px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-13" data-zoom="5" data-speed="500" data-delay="50" style="top:430px;left:350px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-14" data-zoom="5" data-speed="500" data-delay="50" style="top:255px;left:400px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-15" data-zoom="5" data-speed="500" data-delay="50" style="top:170px;left:350px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-16" data-zoom="5" data-speed="500" data-delay="50" style="top:190px;left:550px;width:30px;height:30px;"></div>    
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-17" data-zoom="5" data-speed="500" data-delay="50" style="top:230px;left:130px;width:30px;height:30px;"></div>    

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-1">
		<img class="zt-current" src="images/asklipieio/2.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-2">
		<img class="zt-current" src="images/asklipieio/3.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-11-3">
		<img class="zt-current" src="images/asklipieio/4.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-4">
		<img class="zt-current" src="images/asklipieio/5.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-5">
		<img class="zt-current" src="images/asklipieio/7.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-6">
		<img class="zt-current" src="images/asklipieio/8.jpg" />
    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-7">
		<img class="zt-current" src="images/asklipieio/9.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-8">
		<img class="zt-current" src="images/asklipieio/6.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-9">
		<img class="zt-current" src="images/asklipieio/10.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-10">
		<img class="zt-current" src="images/asklipieio/12.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-11">
		<img class="zt-current" src="images/asklipieio/13.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-12">
		<img class="zt-current" src="images/asklipieio/11.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-13">
		<img class="zt-current" src="images/asklipieio/14.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-14">
		<img class="zt-current" src="images/asklipieio/15.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-11-14-1" data-zoom="5" data-speed="500" data-delay="50" style="top:300px;left:490px;width:30px;height:30px;"></div>    

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-14-1">
		<img class="zt-current" src="images/asklipieio/16.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11-14" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-15">
		<img class="zt-current" src="images/asklipieio/17.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-16">
		<img class="zt-current" src="images/asklipieio/18.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-17">
		<img class="zt-current" src="images/asklipieio/19.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-11-18">
		<img class="zt-current" src="images/asklipieio/20.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!--ASKLIPIEIO-->    
<!-- STADIO -->    
<div class="zt-item" data-id="zt-item-11">
		<img class="zt-current" src="images/stadio/stadio1.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-2" data-zoom="2" data-speed="500" data-delay="0" style="top:390px;left:500px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-3" data-zoom="2" data-speed="500" data-delay="0" style="top:280px;left:460px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-5" data-zoom="2" data-speed="500" data-delay="0" style="top:220px;left:310px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-6" data-zoom="2" data-speed="500" data-delay="0" style="top:120px;left:420px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-7" data-zoom="2" data-speed="500" data-delay="0" style="top:80px;left:240px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-10" data-zoom="2" data-speed="500" data-delay="0" style="top:130px;left:230px;width:30px;height:30px;"></div>
   <div class="zt-tag" data-dir="1" data-link="zt-item-111" data-zoom="2" data-speed="500" data-delay="0" style="top:75px;left:550px;width:30px;height:30px;"></div>
   <div class="zt-tag" data-dir="1" data-link="zt-item-13" data-zoom="2" data-speed="500" data-delay="0" style="top:100px;left:590px;width:30px;height:30px;"></div>
   <div class="zt-tag" data-dir="1" data-link="zt-item-14" data-zoom="2" data-speed="500" data-delay="0" style="top:120px;left:100px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-16" data-zoom="2" data-speed="500" data-delay="0" style="top:150px;left:300px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-17" data-zoom="2" data-speed="500" data-delay="0" style="top:160px;left:570px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-18" data-zoom="2" data-speed="500" data-delay="0" style="top:120px;left:520px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-20" data-zoom="2" data-speed="500" data-delay="0" style="top:170px;left:230px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-27" data-zoom="2" data-speed="500" data-delay="0" style="top:300px;left:90px;width:30px;height:30px;"></div>
   

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-2">
		<img class="zt-current" src="images/stadio/1.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-3">
		<img class="zt-current" src="images/stadio/2.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-5">
		<img class="zt-current" src="images/stadio/3.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-51" data-zoom="2" data-speed="500" data-delay="0" style="top:370px;left:230px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-52" data-zoom="2" data-speed="500" data-delay="0" style="top:320px;left:500px;width:30px;height:30px;"></div>

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-51">
		<img class="zt-current" src="images/stadio/5.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-5" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-52">
		<img class="zt-current" src="images/stadio/6.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-5" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-6">
		<img class="zt-current" src="images/stadio/4.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-7">
		<img class="zt-current" src="images/stadio/7.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-71" data-zoom="2" data-speed="500" data-delay="0" style="top:360px;left:630px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-25" data-zoom="2" data-speed="500" data-delay="0" style="top:435px;left:450px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-26" data-zoom="2" data-speed="500" data-delay="0" style="top:485px;left:450px;width:30px;height:30px;"></div>

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-71">
		<img class="zt-current" src="images/stadio/8.jpg" />
     <div class="zt-tag" data-dir="1" data-link="zt-item-81" data-zoom="2" data-speed="500" data-delay="0" style="top:60px;left:540px;width:30px;height:30px;"></div>

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-7" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-81">
		<img class="zt-current" src="images/stadio/9.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-71" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-10">
		<img class="zt-current" src="images/stadio/10.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-111">
		<img class="zt-current" src="images/stadio/11.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-12" data-zoom="2" data-speed="500" data-delay="0" style="top:600px;left:360px;width:30px;height:30px;"></div>

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-12">
		<img class="zt-current" src="images/stadio/12.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-111" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-13">
		<img class="zt-current" src="images/stadio/13.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-15" data-zoom="2" data-speed="500" data-delay="0" style="top:420px;left:400px;width:30px;height:30px;"></div>

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-15">
		<img class="zt-current" src="images/stadio/15.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-13" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-17">
		<img class="zt-current" src="images/stadio/17.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>


<div class="zt-item" data-id="zt-item-18">
		<img class="zt-current" src="images/stadio/18.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-181" data-zoom="2" data-speed="500" data-delay="0" style="top:390px;left:870px;width:30px;height:30px;"></div>
    
    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-181">
		<img class="zt-current" src="images/stadio/19.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-18" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>


<div class="zt-item" data-id="zt-item-14">
		<img class="zt-current" src="images/stadio/14.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-16">
		<img class="zt-current" src="images/stadio/16.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-20">
		<img class="zt-current" src="images/stadio/20.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-21" data-zoom="2" data-speed="500" data-delay="0" style="top:310px;left:650px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-23" data-zoom="2" data-speed="500" data-delay="0" style="top:330px;left:350px;width:30px;height:30px;"></div>
    
    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-21">
		<img class="zt-current" src="images/stadio/21.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-20" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-22">
		<img class="zt-current" src="images/stadio/22.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-23" data-zoom="15" data-speed="300" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-23">
		<img class="zt-current" src="images/stadio/23.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-22" data-zoom="2" data-speed="300" data-delay="0" style="top:290px;left:550px;width:30px;height:30px;"></div> 
    <div class="zt-tag" data-dir="1" data-link="zt-item-24" data-zoom="2" data-speed="300" data-delay="0" style="top:240px;left:310px;width:30px;height:30px;"></div>       

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-20" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-24">
		<img class="zt-current" src="images/stadio/24.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-23" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-25">
		<img class="zt-current" src="images/stadio/25.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-7" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-26">
		<img class="zt-current" src="images/stadio/26.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-7" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-27">
		<img class="zt-current" src="images/stadio/27.jpg" />

    <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- STADIO -->

<!-- HRWO -->
<div class="zt-item" data-id="zt-item-11-1">
		<img class="zt-current" src="images/hrwo/1.jpg" />
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-1-1" data-zoom="2" data-speed="500" data-delay="0" style="top:390px;left:850px;width:30px;height:30px;"></div>
    <div class="zt-tag" data-dir="1" data-link="zt-item-11-1-2" data-zoom="2" data-speed="500" data-delay="0" style="top:300px;left:570px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-1-1">
		<img class="zt-current" src="images/hrwo/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-1-2">
		<img class="zt-current" src="images/hrwo/3.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-1-4" data-zoom="2" data-speed="500" data-delay="0" style="top:120px;left:470px;width:30px;height:30px;"></div>
        
        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-1-4">
		<img class="zt-current" src="images/hrwo/4.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-1-2" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- HRWO -->

<!-- ISEIO -->
<div class="zt-item" data-id="zt-item-11-2">
		<img class="zt-current" src="images/iseio/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-2-1" data-zoom="2" data-speed="500" data-delay="0" style="top:430px;left:770px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-2-1">
		<img class="zt-current" src="images/iseio/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-2" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- ISEIO -->

<!-- PALAISTRA -->
<div class="zt-item" data-id="zt-item-11-3">
		<img class="zt-current" src="images/palaistra/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-3-1" data-zoom="2" data-speed="500" data-delay="0" style="top:470px;left:740px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-3-2" data-zoom="2" data-speed="500" data-delay="0" style="top:390px;left:210px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-3-3" data-zoom="2" data-speed="500" data-delay="0" style="top:305px;left:640px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-3-1">
		<img class="zt-current" src="images/palaistra/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-3" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-3-2">
		<img class="zt-current" src="images/palaistra/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-3" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-3-3">
		<img class="zt-current" src="images/palaistra/4.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-3" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- PALAISTRA -->

<!-- AGORA -->
<div class="zt-item" data-id="zt-item-11-4">
		<img class="zt-current" src="images/agora/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-4-1" data-zoom="2" data-speed="500" data-delay="0" style="top:210px;left:160px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-4-2" data-zoom="2" data-speed="500" data-delay="0" style="top:200px;left:280px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-4-1">
		<img class="zt-current" src="images/agora/2.jpg" />
       <div class="zt-tag" data-dir="1" data-link="zt-item-11-4-3" data-zoom="2" data-speed="500" data-delay="0" style="top:90px;left:390px;width:30px;height:30px;"></div>       
       <div class="zt-tag" data-dir="1" data-link="zt-item-11-4-4" data-zoom="2" data-speed="500" data-delay="0" style="top:560px;left:150px;width:30px;height:30px;"></div>       

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-4" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-4-2">
		<img class="zt-current" src="images/agora/5.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-4" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-4-3">
		<img class="zt-current" src="images/agora/4.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-4-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-4-4">
		<img class="zt-current" src="images/agora/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-4-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- AGORA -->

<!-- ARSINOH -->
<div class="zt-item" data-id="zt-item-11-5">
		<img class="zt-current" src="images/arsinoh/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-5-1" data-zoom="2" data-speed="500" data-delay="0" style="top:210px;left:860px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-5-2" data-zoom="2" data-speed="500" data-delay="0" style="top:400px;left:55px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-5-3" data-zoom="2" data-speed="500" data-delay="0" style="top:200px;left:160px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-5-1">
		<img class="zt-current" src="images/arsinoh/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-5" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-5-2">
		<img class="zt-current" src="images/arsinoh/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-5" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-5-3">
		<img class="zt-current" src="images/arsinoh/4.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-5" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>


<!-- ARSINOH -->

<!-- BASILIKH -->
<div class="zt-item" data-id="zt-item-11-6">
		<img class="zt-current" src="images/vasilikh/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-6-1" data-zoom="2" data-speed="500" data-delay="0" style="top:110px;left:560px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-6-2" data-zoom="2" data-speed="500" data-delay="0" style="top:450px;left:300px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-6-1">
		<img class="zt-current" src="images/vasilikh/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-6" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-6-2">
		<img class="zt-current" src="images/vasilikh/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-6" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- BASILIKH -->


<!-- RWMAIKH VILA -->
<div class="zt-item" data-id="zt-item-11-7">
		<img class="zt-current" src="images/rwmaikh vila/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-7-1" data-zoom="2" data-speed="500" data-delay="0" style="top:270px;left:445px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-7-2" data-zoom="2" data-speed="500" data-delay="0" style="top:400px;left:300px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-7-1">
		<img class="zt-current" src="images/rwmaikh vila/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-7" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-7-2">
		<img class="zt-current" src="images/rwmaikh vila/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-7" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- RWMAIKH VILA -->

<!-- VILLA STADIOU -->
<div class="zt-item" data-id="zt-item-11-8">
		<img class="zt-current" src="images/villa stadiou/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-8-1" data-zoom="2" data-speed="500" data-delay="0" style="top:225px;left:565px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-8-1">
		<img class="zt-current" src="images/villa stadiou/2.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-8-2" data-zoom="2" data-speed="500" data-delay="0" style="top:200px;left:500px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-8" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-8-2">
		<img class="zt-current" src="images/villa stadiou/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-8-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- VILLA STADIOU -->

<!-- THEATRO -->
<div class="zt-item" data-id="zt-item-11-9">
		<img class="zt-current" src="images/theatro/1.jpg" />
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-1" data-zoom="2" data-speed="500" data-delay="0" style="top:425px;left:555px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-2" data-zoom="2" data-speed="500" data-delay="0" style="top:30px;left:200px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-3" data-zoom="2" data-speed="500" data-delay="0" style="top:255px;left:120px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-4" data-zoom="2" data-speed="500" data-delay="0" style="top:580px;left:850px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-5" data-zoom="2" data-speed="500" data-delay="0" style="top:480px;left:400px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-6" data-zoom="2" data-speed="500" data-delay="0" style="top:430px;left:450px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-7" data-zoom="2" data-speed="500" data-delay="0" style="top:155px;left:100px;width:30px;height:30px;"></div>
        <div class="zt-tag" data-dir="1" data-link="zt-item-11-9-8" data-zoom="2" data-speed="500" data-delay="0" style="top:290px;left:70px;width:30px;height:30px;"></div>

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-9-1">
		<img class="zt-current" src="images/theatro/2.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-9-2">
		<img class="zt-current" src="images/theatro/3.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-9-3">
		<img class="zt-current" src="images/theatro/4.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-9-4">
		<img class="zt-current" src="images/theatro/5.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<div class="zt-item" data-id="zt-item-11-9-5">
		<img class="zt-current" src="images/theatro/6.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
        
</div><div class="zt-item" data-id="zt-item-11-9-6">
		<img class="zt-current" src="images/theatro/7.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-9-7">
		<img class="zt-current" src="images/theatro/8.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>

<div class="zt-item" data-id="zt-item-11-9-8">
		<img class="zt-current" src="images/theatro/9.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-11-9" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!--agios nikolaos-->
<div class="zt-item" data-id="zt-item-11-9-9">
		<img class="zt-current" src="images/theatro/10.jpg" />

        <div class="zt-tag zt-tag-back" data-dir="-1" data-link="zt-item-1" data-zoom="15" data-speed="500" data-delay="0"></div>
</div>
<!-- THEATRO -->
<!---END DIV -->
</div>